import money from '../../conf/function.js';
import moment from 'moment';
import db from '../../models/model.js';

export const newuser = async (req, res) => {
	// set the header
	res.setHeader('Content-Type', 'application/json');

	// get data from req
	const data = {
		name: req.query.name,
		user: req.query.account,
		timeAdded: moment(new Date()).format("dddd, MMMM Do YYYY, h:mm a")
	};
	
	// insert d data
	try {
		let newUser = new db(data);
		
		let user = await db.findOne(data)
		console.log(user);
		if (user) res.json({code: 0, msg: 'Customer with the same name exist'});
		else newUser = await newUser.save();
		res.json({code: 1, msg: data.name + ' has been added to customers list'});
	} catch (e) {
		console.log(e.message);
	}
}

export const userinfo = async (req, res) => {
	// set the header
	res.setHeader('Content-Type', 'application/json');

	let user = await db.findOne({'_id': req.params.id})
	let total = 0;
	let tab = 0;

	// calculate the total debt still being owe!
	if (user.paid && user.tab) {
		user.paid.forEach(p => {
			total += Number(p.amount);
		});
		
		user.tab.forEach(t => {
			tab += Number(t.total);
		});
		
		total = tab - total;
	}
	total = money(total);
	
	res.json({name: user.name, tab: user.tab, paid: user.paid, debt: total});
}

export const userreset = async (req, res) => {
	// set the header
	res.setHeader('Content-Type', 'application/json');
	await db.update({'_id': req.params.id}, {$unset: {
		tab: true,
		paid: true
	}});
	res.json({
	  code: 1,
	  msg: 'Reset successfully!'
	});
}
export const googleRouter = (req, res) => {
	res.send('hello');
}

export const local = (req, res) => {
	res.send('login page');
}